// Configuration for the application
const appConfig = {
    appName: "FakeBank Financial",
    version: "1.0",
    apiBaseUrl: "https://api.fakebank.com"
  };
  
  console.log(`Loaded ${appConfig.appName} configuration, version ${appConfig.version}`);
  